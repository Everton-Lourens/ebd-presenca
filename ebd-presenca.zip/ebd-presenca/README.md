# EBD Presença

Aplicação web local para lista de presença da Escola Bíblica Dominical, feita com:

- Node.js
- Express.js
- SQLite com `better-sqlite3`
- Frontend com HTML, CSS e JavaScript puro

## Funcionalidades

- Cadastro de alunos por classe
- Chamada por domingo
- Registro de presença, falta, visitantes e oferta
- Bloqueio de chamada duplicada no mesmo domingo e mesma classe
- Inativação automática após 4 faltas consecutivas
- Reativação manual de alunos
- Relatórios por classe
- Relatórios individuais
- Relatório geral
- Relatório trimestral com exportação em TXT ou HTML

## Classes fixas

- Crianças Menores
- Crianças Maiores
- Adolescentes
- Jovens
- Senhores
- Senhoras

## Instalação

1. Entre na pasta do projeto:

```bash
cd ebd-presenca
```

2. Instale as dependências:

```bash
npm install
```

3. Inicie o servidor:

```bash
npm start
```

4. Abra no navegador:

```bash
http://localhost:3000
```

## Estrutura

```text
ebd-presenca/
├── server.js
├── database.js
├── package.json
├── README.md
├── routes/
│   ├── alunos.js
│   ├── chamada.js
│   └── relatorios.js
└── public/
    ├── index.html
    ├── style.css
    └── app.js
```

## Banco de dados

O arquivo SQLite é criado automaticamente em:

```text
ebd.sqlite3
```

na raiz do projeto.

## API

### Alunos
- `GET /api/alunos`
- `GET /api/alunos/:id`
- `POST /api/alunos`
- `PUT /api/alunos/:id`
- `PATCH /api/alunos/:id/reativar`
- `DELETE /api/alunos/:id`

### Chamada
- `GET /api/chamada`
- `GET /api/chamada/:id`
- `POST /api/chamada`

### Relatórios
- `GET /api/relatorios/geral`
- `GET /api/relatorios/classe/:classId`
- `GET /api/relatorios/aluno/:id`
- `GET /api/relatorios/trimestral?year=2026&quarter=1`
- `GET /api/relatorios/trimestral/export?year=2026&quarter=1&format=txt`
- `GET /api/relatorios/trimestral/export?year=2026&quarter=1&format=html`

## Observações

- A chamada só pode ser salva para domingos.
- Alunos inativos não aparecem na chamada.
- Ao registrar a chamada de uma classe, o sistema grava automaticamente presença/falta de todos os alunos ativos daquela classe.
- Após cada chamada, o sistema recalcula a sequência de faltas consecutivas e inativa automaticamente quem atingir 4 faltas seguidas.
