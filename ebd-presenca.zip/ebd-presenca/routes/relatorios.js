const express = require('express');
const { db, getClasses } = require('../database');

const router = express.Router();

function quarterRange(year, quarter) {
  const q = Number(quarter);
  const y = Number(year);
  if (!Number.isInteger(y) || !Number.isInteger(q) || q < 1 || q > 4) return null;
  const months = { 1: ['01', '02', '03'], 2: ['04', '05', '06'], 3: ['07', '08', '09'], 4: ['10', '11', '12'] }[q];
  return { start: `${y}-${months[0]}-01`, end: `${y}-${months[2]}-31` };
}

function percentage(p, t) { return t ? (p / t) * 100 : 0; }

router.get('/geral', (req, res) => {
  const totalAtivos = db.prepare('SELECT COUNT(*) AS total FROM alunos WHERE status = \'ativa\'').get().total;
  const totalPresencas = db.prepare('SELECT COUNT(*) AS total FROM chamada_alunos WHERE presente = 1').get().total;
  const totalOfertas = db.prepare('SELECT COALESCE(SUM(offer_amount), 0) AS total FROM chamadas').get().total;
  const totalVisitantes = db.prepare('SELECT COUNT(*) AS total FROM visitantes').get().total;
  const ranking = db.prepare(`
    SELECT a.id, a.nome_completo, c.nome AS classe,
           SUM(CASE WHEN ca.presente = 1 THEN 1 ELSE 0 END) AS presencas,
           COUNT(ch.id) AS domingos,
           ROUND(CASE WHEN COUNT(ch.id) = 0 THEN 0 ELSE (SUM(CASE WHEN ca.presente = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(ch.id)) END, 2) AS percentual
    FROM alunos a
    JOIN classes c ON c.id = a.class_id
    LEFT JOIN chamadas ch ON ch.class_id = a.class_id
    LEFT JOIN chamada_alunos ca ON ca.chamada_id = ch.id AND ca.aluno_id = a.id
    GROUP BY a.id
    ORDER BY percentual DESC, presencas DESC, a.nome_completo COLLATE NOCASE ASC
    LIMIT 10
  `).all();
  const perSunday = db.prepare(`
    SELECT ch.sunday_date,
           COUNT(CASE WHEN ca.presente = 1 THEN 1 END) AS presentes,
           COUNT(ca.id) AS registros
    FROM chamadas ch
    LEFT JOIN chamada_alunos ca ON ca.chamada_id = ch.id
    GROUP BY ch.id
    ORDER BY ch.sunday_date ASC, ch.id ASC
  `).all();
  const totalPossiveis = db.prepare(`
    SELECT COUNT(*) AS total
    FROM chamadas ch
    JOIN alunos a ON a.class_id = ch.class_id AND a.status = 'ativa'
  `).get().total;
  res.json({
    total_ativos: totalAtivos,
    total_presencas: totalPresencas,
    percentual_geral: percentage(totalPresencas, totalPossiveis),
    total_ofertas: totalOfertas,
    total_visitantes: totalVisitantes,
    ranking_geral: ranking,
    presencas_por_domingo: perSunday,
    classes: getClasses()
  });
});

router.get('/classe/:classId', (req, res) => {
  const classId = Number(req.params.classId);
  const classe = db.prepare('SELECT id, nome FROM classes WHERE id = ?').get(classId);
  if (!classe) return res.status(404).json({ error: 'Classe não encontrada.' });
  const totalAtivos = db.prepare('SELECT COUNT(*) AS total FROM alunos WHERE class_id = ? AND status = \'ativa\'').get(classId).total;
  const listaDomingos = db.prepare(`
    SELECT ch.id, ch.sunday_date, ch.offer_amount,
           COUNT(CASE WHEN ca.presente = 1 THEN 1 END) AS presentes
    FROM chamadas ch
    LEFT JOIN chamada_alunos ca ON ca.chamada_id = ch.id
    WHERE ch.class_id = ?
    GROUP BY ch.id
    ORDER BY ch.sunday_date ASC, ch.id ASC
  `).all(classId).map(row => ({ ...row, percentual_presenca: percentage(row.presentes, totalAtivos) }));
  const melhores = db.prepare(`
    SELECT a.id, a.nome_completo,
           COUNT(CASE WHEN ca.presente = 1 THEN 1 END) AS presencas,
           COUNT(ch.id) AS domingos
    FROM alunos a
    LEFT JOIN chamadas ch ON ch.class_id = a.class_id
    LEFT JOIN chamada_alunos ca ON ca.chamada_id = ch.id AND ca.aluno_id = a.id
    WHERE a.class_id = ?
    GROUP BY a.id
    ORDER BY presencas DESC, domingos DESC, a.nome_completo COLLATE NOCASE ASC
    LIMIT 10
  `).all(classId).map(row => ({ ...row, percentual: percentage(row.presencas, row.domingos) }));
  const risco = db.prepare(`
    SELECT a.id, a.nome_completo, a.status,
           SUM(CASE WHEN ca.presente = 0 THEN 1 ELSE 0 END) AS faltas,
           COUNT(ch.id) AS domingos
    FROM alunos a
    LEFT JOIN chamadas ch ON ch.class_id = a.class_id
    LEFT JOIN chamada_alunos ca ON ca.chamada_id = ch.id AND ca.aluno_id = a.id
    WHERE a.class_id = ?
    GROUP BY a.id
    HAVING faltas >= 2 OR a.status = 'inativa'
    ORDER BY faltas DESC, a.nome_completo COLLATE NOCASE ASC
  `).all(classId);
  const visitantes = db.prepare('SELECT COUNT(*) AS total FROM visitantes v JOIN chamadas ch ON ch.id = v.chamada_id WHERE ch.class_id = ?').get(classId).total;
  const ofertas = db.prepare('SELECT COALESCE(SUM(offer_amount), 0) AS total FROM chamadas WHERE class_id = ?').get(classId).total;
  res.json({ classe, total_ativos: totalAtivos, domingos: listaDomingos, melhores_alunos: melhores, alunos_em_risco: risco, total_visitantes: visitantes, total_ofertas: ofertas });
});

router.get('/aluno/:id', (req, res) => {
  const studentId = Number(req.params.id);
  const aluno = db.prepare(`
    SELECT a.id, a.nome_completo, a.class_id, a.data_cadastro, a.status, a.inactive_reason, c.nome AS classe
    FROM alunos a
    JOIN classes c ON c.id = a.class_id
    WHERE a.id = ?
  `).get(studentId);
  if (!aluno) return res.status(404).json({ error: 'Aluno não encontrado.' });
  const rows = db.prepare(`
    SELECT ch.id AS chamada_id, ch.sunday_date, ca.presente
    FROM chamadas ch
    LEFT JOIN chamada_alunos ca ON ca.chamada_id = ch.id AND ca.aluno_id = ?
    WHERE ch.class_id = ?
    ORDER BY ch.sunday_date ASC, ch.id ASC
  `).all(studentId, aluno.class_id);
  const presencas = rows.filter(r => r.presente === 1).length;
  const faltas = rows.filter(r => r.presente === 0).length;
  let streak = 0;
  for (const row of rows) { if (row.presente === 1) streak = 0; else if (row.presente === 0) streak += 1; }
  res.json({ aluno, total_domingos: rows.length, presencas, faltas, percentual_presenca: rows.length ? (presencas / rows.length) * 100 : 0, faltas_consecutivas: streak, historico: rows });
});

router.get('/trimestral', (req, res) => {
  const range = quarterRange(req.query.year, req.query.quarter);
  if (!range) return res.status(400).json({ error: 'Parâmetros de trimestre inválidos.' });
  const classes = getClasses();
  const calls = db.prepare('SELECT id, class_id, sunday_date, offer_amount FROM chamadas WHERE sunday_date BETWEEN ? AND ? ORDER BY sunday_date ASC, id ASC').all(range.start, range.end);
  const totalOfertas = db.prepare('SELECT COALESCE(SUM(offer_amount), 0) AS total FROM chamadas WHERE sunday_date BETWEEN ? AND ?').get(range.start, range.end).total;
  const totalVisitantes = db.prepare('SELECT COUNT(*) AS total FROM visitantes v JOIN chamadas ch ON ch.id = v.chamada_id WHERE ch.sunday_date BETWEEN ? AND ?').get(range.start, range.end).total;
  const rankingGeral = db.prepare(`
    SELECT a.id, a.nome_completo, c.nome AS classe,
           SUM(CASE WHEN ca.presente = 1 THEN 1 ELSE 0 END) AS presencas,
           COUNT(ch.id) AS domingos,
           ROUND(CASE WHEN COUNT(ch.id) = 0 THEN 0 ELSE (SUM(CASE WHEN ca.presente = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(ch.id)) END, 2) AS percentual
    FROM alunos a
    JOIN classes c ON c.id = a.class_id
    LEFT JOIN chamadas ch ON ch.class_id = a.class_id AND ch.sunday_date BETWEEN ? AND ?
    LEFT JOIN chamada_alunos ca ON ca.chamada_id = ch.id AND ca.aluno_id = a.id
    GROUP BY a.id
    ORDER BY percentual DESC, presencas DESC, a.nome_completo COLLATE NOCASE ASC
    LIMIT 20
  `).all(range.start, range.end);
  const rankingPorClasse = classes.map(classe => {
    const alunos = db.prepare(`
      SELECT a.id, a.nome_completo,
             SUM(CASE WHEN ca.presente = 1 THEN 1 ELSE 0 END) AS presencas,
             COUNT(ch.id) AS domingos,
             ROUND(CASE WHEN COUNT(ch.id) = 0 THEN 0 ELSE (SUM(CASE WHEN ca.presente = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(ch.id)) END, 2) AS percentual
      FROM alunos a
      LEFT JOIN chamadas ch ON ch.class_id = a.class_id AND ch.sunday_date BETWEEN ? AND ?
      LEFT JOIN chamada_alunos ca ON ca.chamada_id = ch.id AND ca.aluno_id = a.id
      WHERE a.class_id = ?
      GROUP BY a.id
      ORDER BY percentual DESC, presencas DESC, a.nome_completo COLLATE NOCASE ASC
      LIMIT 10
    `).all(range.start, range.end, classe.id);
    return { classe, alunos };
  });
  const htmlExport = `
    <html>
    <head>
      <meta charset="utf-8" />
      <title>Relatório Trimestral EBD</title>
      <style>
        body{font-family:Arial,sans-serif;padding:24px;line-height:1.5;color:#111}
        h1,h2,h3{margin:0 0 12px}
        table{width:100%;border-collapse:collapse;margin:12px 0 24px}
        th,td{border:1px solid #ddd;padding:8px;text-align:left}
        th{background:#f3f3f3}
      </style>
    </head>
    <body>
      <h1>Relatório Trimestral EBD</h1>
      <p><strong>Período:</strong> ${range.start} até ${range.end}</p>
      <p><strong>Total de ofertas:</strong> ${Number(totalOfertas).toFixed(2)}</p>
      <p><strong>Total de visitantes:</strong> ${totalVisitantes}</p>
      <h2>Ranking Geral</h2>
      <table><thead><tr><th>Aluno</th><th>Classe</th><th>Presenças</th><th>Domingos</th><th>%</th></tr></thead><tbody>
        ${rankingGeral.map(a => `<tr><td>${a.nome_completo}</td><td>${a.classe}</td><td>${a.presencas}</td><td>${a.domingos}</td><td>${Number(a.percentual).toFixed(2)}%</td></tr>`).join('')}
      </tbody></table>
      ${rankingPorClasse.map(item => `<h2>${item.classe.nome}</h2><table><thead><tr><th>Aluno</th><th>Presenças</th><th>Domingos</th><th>%</th></tr></thead><tbody>${item.alunos.map(a => `<tr><td>${a.nome_completo}</td><td>${a.presencas}</td><td>${a.domingos}</td><td>${Number(a.percentual).toFixed(2)}%</td></tr>`).join('')}</tbody></table>`).join('')}
    </body>
    </html>
  `;
  res.json({ periodo: range, total_ofertas: totalOfertas, total_visitantes: totalVisitantes, ranking_geral: rankingGeral, ranking_por_classe: rankingPorClasse, chamadas: calls, export_html: htmlExport });
});

router.get('/trimestral/export', (req, res) => {
  const range = quarterRange(req.query.year, req.query.quarter);
  if (!range) return res.status(400).send('Parâmetros de trimestre inválidos.');
  const report = db.prepare(`
    SELECT a.nome_completo, c.nome AS classe,
           SUM(CASE WHEN ca.presente = 1 THEN 1 ELSE 0 END) AS presencas,
           COUNT(ch.id) AS domingos
    FROM alunos a
    JOIN classes c ON c.id = a.class_id
    LEFT JOIN chamadas ch ON ch.class_id = a.class_id AND ch.sunday_date BETWEEN ? AND ?
    LEFT JOIN chamada_alunos ca ON ca.chamada_id = ch.id AND ca.aluno_id = a.id
    GROUP BY a.id
    ORDER BY presencas DESC, domingos DESC, a.nome_completo COLLATE NOCASE ASC
  `).all(range.start, range.end);
  if (String(req.query.format || 'txt').toLowerCase() === 'html') {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    return res.send(`<html><head><meta charset="utf-8"><title>Relatório Trimestral EBD</title></head><body><pre>${JSON.stringify({ periodo: range, report }, null, 2)}</pre></body></html>`);
  }
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.send(['Relatório Trimestral EBD', `Período: ${range.start} até ${range.end}`, '', ...report.map((r, i) => `${i + 1}. ${r.nome_completo} - ${r.classe} - Presenças: ${r.presencas} - Domingos: ${r.domingos}`)].join('\n'));
});

module.exports = router;
