const express = require('express');
const { db, isSunday, recalculateClassAttendanceStatus } = require('../database');

const router = express.Router();

function normalizeDate(value) {
  return typeof value === 'string' ? value.slice(0, 10) : value;
}

function uniqueSunday(classId, sundayDate) {
  return !db.prepare('SELECT id FROM chamadas WHERE class_id = ? AND sunday_date = ?').get(classId, sundayDate);
}

router.get('/', (req, res) => {
  const { class_id, start, end } = req.query;
  let sql = `
    SELECT ch.id, ch.class_id, ch.sunday_date, ch.offer_amount, c.nome AS classe
    FROM chamadas ch
    JOIN classes c ON c.id = ch.class_id
    WHERE 1=1
  `;
  const params = [];
  if (class_id) { sql += ' AND ch.class_id = ?'; params.push(Number(class_id)); }
  if (start) { sql += ' AND ch.sunday_date >= ?'; params.push(normalizeDate(start)); }
  if (end) { sql += ' AND ch.sunday_date <= ?'; params.push(normalizeDate(end)); }
  sql += ' ORDER BY ch.sunday_date DESC, ch.id DESC';
  res.json(db.prepare(sql).all(...params));
});

router.get('/:id', (req, res) => {
  const chamada = db.prepare(`
    SELECT ch.id, ch.class_id, ch.sunday_date, ch.offer_amount, c.nome AS classe
    FROM chamadas ch
    JOIN classes c ON c.id = ch.class_id
    WHERE ch.id = ?
  `).get(req.params.id);
  if (!chamada) return res.status(404).json({ error: 'Chamada não encontrada.' });
  const alunos = db.prepare(`
    SELECT ca.aluno_id, ca.presente, a.nome_completo
    FROM chamada_alunos ca
    JOIN alunos a ON a.id = ca.aluno_id
    WHERE ca.chamada_id = ?
    ORDER BY a.nome_completo COLLATE NOCASE ASC
  `).all(req.params.id);
  const visitantes = db.prepare('SELECT id, nome, classe_visitada FROM visitantes WHERE chamada_id = ? ORDER BY id ASC').all(req.params.id);
  res.json({ ...chamada, alunos, visitantes });
});

router.post('/', (req, res) => {
  const classId = Number(req.body.class_id);
  const sundayDate = normalizeDate(req.body.sunday_date);
  const offerAmount = Number(req.body.offer_amount || 0);
  const presentStudentIds = Array.isArray(req.body.present_student_ids) ? req.body.present_student_ids.map(Number).filter(Number.isInteger) : [];
  const visitors = Array.isArray(req.body.visitors) ? req.body.visitors : [];

  if (!Number.isInteger(classId) || classId <= 0) return res.status(400).json({ error: 'Classe inválida.' });
  if (!sundayDate) return res.status(400).json({ error: 'Data do domingo é obrigatória.' });
  if (!isSunday(sundayDate)) return res.status(400).json({ error: 'A chamada só pode ser registrada para domingo.' });
  if (!uniqueSunday(classId, sundayDate)) return res.status(409).json({ error: 'Já existe chamada para esta classe neste domingo.' });

  const activeStudents = db.prepare(`
    SELECT id, nome_completo
    FROM alunos
    WHERE class_id = ? AND status = 'ativa'
    ORDER BY nome_completo COLLATE NOCASE ASC
  `).all(classId);

  const activeIds = new Set(activeStudents.map(a => a.id));
  for (const id of presentStudentIds) {
    if (!activeIds.has(id)) return res.status(400).json({ error: 'Um ou mais alunos presentes não pertencem à classe ou estão inativos.' });
  }

  const tx = db.transaction(() => {
    const called = db.prepare('INSERT INTO chamadas (class_id, sunday_date, offer_amount) VALUES (?, ?, ?)').run(classId, sundayDate, offerAmount);
    const chamadaId = called.lastInsertRowid;
    const ins = db.prepare('INSERT INTO chamada_alunos (chamada_id, aluno_id, presente) VALUES (?, ?, ?)');
    for (const aluno of activeStudents) ins.run(chamadaId, aluno.id, presentStudentIds.includes(aluno.id) ? 1 : 0);
    const insVisitor = db.prepare('INSERT INTO visitantes (chamada_id, nome, classe_visitada) VALUES (?, ?, ?)');
    for (const visitor of visitors) {
      const nome = String(visitor.nome || '').trim();
      const classeVisitada = String(visitor.classe_visitada || '').trim();
      if (!nome || !classeVisitada) continue;
      insVisitor.run(chamadaId, nome, classeVisitada);
    }
    return chamadaId;
  });

  try {
    const chamadaId = tx();
    recalculateClassAttendanceStatus(classId);
    const created = db.prepare(`
      SELECT ch.id, ch.class_id, ch.sunday_date, ch.offer_amount, c.nome AS classe
      FROM chamadas ch
      JOIN classes c ON c.id = ch.class_id
      WHERE ch.id = ?
    `).get(chamadaId);
    res.status(201).json({ ok: true, chamada: created });
  } catch {
    res.status(500).json({ error: 'Erro ao registrar chamada.' });
  }
});

module.exports = router;
