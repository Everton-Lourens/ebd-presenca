const express = require('express');
const { db } = require('../database');

const router = express.Router();

function validateAlunoPayload(body) {
  const nome = (body.nome_completo || '').trim();
  const classId = Number(body.class_id);
  const dataCadastro = (body.data_cadastro || '').trim();
  const status = (body.status || 'ativa').trim();

  if (!nome) return 'Nome completo é obrigatório.';
  if (!Number.isInteger(classId) || classId <= 0) return 'Classe inválida.';
  if (!dataCadastro) return 'Data de cadastro é obrigatória.';
  if (!['ativa', 'inativa'].includes(status)) return 'Status inválido.';
  return null;
}

router.get('/', (req, res) => {
  const { class_id, status } = req.query;
  let sql = `
    SELECT a.id, a.nome_completo, a.class_id, a.data_cadastro, a.status, a.inactive_reason,
           c.nome AS classe
    FROM alunos a
    JOIN classes c ON c.id = a.class_id
    WHERE 1=1
  `;
  const params = [];
  if (class_id) { sql += ' AND a.class_id = ?'; params.push(Number(class_id)); }
  if (status && ['ativa', 'inativa'].includes(status)) { sql += ' AND a.status = ?'; params.push(status); }
  sql += ' ORDER BY a.nome_completo COLLATE NOCASE ASC';
  res.json(db.prepare(sql).all(...params));
});

router.get('/:id', (req, res) => {
  const aluno = db.prepare(`
    SELECT a.id, a.nome_completo, a.class_id, a.data_cadastro, a.status, a.inactive_reason,
           c.nome AS classe
    FROM alunos a
    JOIN classes c ON c.id = a.class_id
    WHERE a.id = ?
  `).get(req.params.id);
  if (!aluno) return res.status(404).json({ error: 'Aluno não encontrado.' });
  res.json(aluno);
});

router.post('/', (req, res) => {
  const error = validateAlunoPayload(req.body);
  if (error) return res.status(400).json({ error });
  try {
    const info = db.prepare(`
      INSERT INTO alunos (nome_completo, class_id, data_cadastro, status, updated_at)
      VALUES (?, ?, ?, ?, datetime('now'))
    `).run(req.body.nome_completo.trim(), Number(req.body.class_id), req.body.data_cadastro.trim(), req.body.status.trim());
    res.status(201).json(db.prepare('SELECT * FROM alunos WHERE id = ?').get(info.lastInsertRowid));
  } catch {
    res.status(500).json({ error: 'Erro ao cadastrar aluno.' });
  }
});

router.put('/:id', (req, res) => {
  const error = validateAlunoPayload(req.body);
  if (error) return res.status(400).json({ error });
  if (!db.prepare('SELECT id FROM alunos WHERE id = ?').get(req.params.id)) {
    return res.status(404).json({ error: 'Aluno não encontrado.' });
  }
  try {
    db.prepare(`
      UPDATE alunos
      SET nome_completo = ?, class_id = ?, data_cadastro = ?, status = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(req.body.nome_completo.trim(), Number(req.body.class_id), req.body.data_cadastro.trim(), req.body.status.trim(), req.params.id);
    res.json(db.prepare('SELECT * FROM alunos WHERE id = ?').get(req.params.id));
  } catch {
    res.status(500).json({ error: 'Erro ao atualizar aluno.' });
  }
});

router.patch('/:id/reativar', (req, res) => {
  if (!db.prepare('SELECT id FROM alunos WHERE id = ?').get(req.params.id)) {
    return res.status(404).json({ error: 'Aluno não encontrado.' });
  }
  db.prepare(`
    UPDATE alunos
    SET status = 'ativa', inactive_reason = NULL, updated_at = datetime('now')
    WHERE id = ?
  `).run(req.params.id);
  res.json(db.prepare('SELECT * FROM alunos WHERE id = ?').get(req.params.id));
});

router.delete('/:id', (req, res) => {
  if (!db.prepare('SELECT id FROM alunos WHERE id = ?').get(req.params.id)) {
    return res.status(404).json({ error: 'Aluno não encontrado.' });
  }
  db.prepare('DELETE FROM alunos WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
