const express = require('express');
const path = require('path');
const { initDatabase, getClasses } = require('./database');

initDatabase();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/alunos', require('./routes/alunos'));
app.use('/api/chamada', require('./routes/chamada'));
app.use('/api/relatorios', require('./routes/relatorios'));

app.get('/api/classes', (req, res) => res.json(getClasses()));
app.get('/api/health', (req, res) => res.json({ ok: true, message: 'Servidor EBD no ar' }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, () => console.log(`EBD Presença rodando em http://localhost:${PORT}`));
