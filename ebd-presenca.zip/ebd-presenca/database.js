const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, 'ebd.sqlite3');
const db = new Database(dbPath);

db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');

function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS classes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL UNIQUE
    );

    CREATE TABLE IF NOT EXISTS alunos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome_completo TEXT NOT NULL,
      class_id INTEGER NOT NULL,
      data_cadastro TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'ativa' CHECK(status IN ('ativa', 'inativa')),
      inactive_reason TEXT DEFAULT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (class_id) REFERENCES classes(id)
    );

    CREATE TABLE IF NOT EXISTS chamadas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      class_id INTEGER NOT NULL,
      sunday_date TEXT NOT NULL,
      offer_amount REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(class_id, sunday_date),
      FOREIGN KEY (class_id) REFERENCES classes(id)
    );

    CREATE TABLE IF NOT EXISTS chamada_alunos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chamada_id INTEGER NOT NULL,
      aluno_id INTEGER NOT NULL,
      presente INTEGER NOT NULL CHECK(presente IN (0, 1)),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(chamada_id, aluno_id),
      FOREIGN KEY (chamada_id) REFERENCES chamadas(id) ON DELETE CASCADE,
      FOREIGN KEY (aluno_id) REFERENCES alunos(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS visitantes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chamada_id INTEGER NOT NULL,
      nome TEXT NOT NULL,
      classe_visitada TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (chamada_id) REFERENCES chamadas(id) ON DELETE CASCADE
    );
  `);

  const classes = [
    'Crianças Menores',
    'Crianças Maiores',
    'Adolescentes',
    'Jovens',
    'Senhores',
    'Senhoras'
  ];

  const insertClass = db.prepare('INSERT OR IGNORE INTO classes (nome) VALUES (?)');
  const tx = db.transaction(() => {
    for (const nome of classes) insertClass.run(nome);
  });
  tx();
}

function getClasses() {
  return db.prepare('SELECT id, nome FROM classes ORDER BY id').all();
}

function parseDate(value) {
  const d = new Date(`${value}T12:00:00`);
  return Number.isNaN(d.getTime()) ? null : d;
}

function isSunday(value) {
  const d = parseDate(value);
  return d ? d.getDay() === 0 : false;
}

function updateStudentInactivation(studentId, streak) {
  if (streak >= 4) {
    db.prepare(`
      UPDATE alunos
      SET status = 'inativa', inactive_reason = '4 faltas consecutivas', updated_at = datetime('now')
      WHERE id = ?
    `).run(studentId);
  }
}

function recalculateClassAttendanceStatus(classId) {
  const students = db.prepare('SELECT id FROM alunos WHERE class_id = ?').all(classId);
  const calls = db.prepare(`
    SELECT id
    FROM chamadas
    WHERE class_id = ?
    ORDER BY sunday_date ASC, id ASC
  `).all(classId);

  for (const student of students) {
    let streak = 0;
    for (const call of calls) {
      const row = db.prepare(`
        SELECT presente
        FROM chamada_alunos
        WHERE chamada_id = ? AND aluno_id = ?
      `).get(call.id, student.id);

      if (!row) continue;
      if (row.presente === 1) streak = 0;
      else streak += 1;
    }
    updateStudentInactivation(student.id, streak);
  }
}

module.exports = { db, initDatabase, getClasses, isSunday, recalculateClassAttendanceStatus };
